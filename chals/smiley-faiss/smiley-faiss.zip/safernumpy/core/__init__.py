import safernumpy.core.multiarray
# nuh uh
